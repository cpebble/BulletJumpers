function initSkyBox()

end